import React from 'react';

function Person() {
    return (
        <div>
            <h1>I am person component</h1>
        </div>
    );
}

export default Person;